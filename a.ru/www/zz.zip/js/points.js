class Point {
    constructor(x, y) {
      this.x = x;
      this.y = y;
    }
  
    print() {
      let point = document.createElement("img");
      point.src = "../img/Circle-icon.png";
    }
  
  }
  